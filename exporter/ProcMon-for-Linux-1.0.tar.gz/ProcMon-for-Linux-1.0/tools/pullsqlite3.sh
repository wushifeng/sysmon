#!/bin/bash

wget https://www.sqlite.org/2019/sqlite-amalgamation-3270200.zip
unzip sqlite-amalgamation-3270200.zip
mv sqlite-amalgamation-3270200 sqlite3
rm sqlite-amalgamation-3270200.zip

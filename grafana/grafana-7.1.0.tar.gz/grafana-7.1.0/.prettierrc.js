module.exports = {
  ...require('@grafana/toolkit/src/config/prettier.plugin.config.json'),
};

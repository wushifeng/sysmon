# Roadmap

The roadmap is a tentative plan for the core development team. Things change constantly as pull requests come in and priorities change, but it will give you an idea of our current vision and plan. 
  
To view the Roadmap, go to the Issues tab on GitHub. There you will find three roadmap issues pinned at the top.
